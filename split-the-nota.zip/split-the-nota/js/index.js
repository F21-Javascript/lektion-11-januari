//Dessa är alla variabler du behöver använda. 
//De ska dock ligga i olika funktioner och inte nedanför.

/*const tip;
const sum;
const numberOfFriends;
const total;
const friendSum;
const sumDivided;
const calculatedTip;
const total; */

//Hämtar det som skrivits i inputfältet med ID tip
document.getElementById('tip').value;

function calculateTip(sum, tip) {}

const buttonElem = document.getElementById('calculateButton');

buttonElem.addEventListener('click', () => {});

//Hämtar det som skrivits i inputfältet med ID sum
document.getElementById('sum').value;

calculateTip(sum, tip);

parseInt(sum) + calculatedTip;

function divideTotal(total, numberOfFriends) {}

//Skriver ut summan i HTML-elementet med ID friendSum
document.getElementById('friendSum').innerHTML = sum + ' kr';

//Returnerar värdet i variablen sumDivided i en funktion
return sumDivided;

showDividedSum(friendSum);

//Lägger till eller tar bort en CSS-klass hide
document.getElementById('showSum').classList.toggle('hide');

total / parseInt(numberOfFriends);

function showDividedSum(sum) {}

document.getElementById('inputForm').classList.toggle('hide');

parseInt(sum) * parseFloat(tip);

//Returnerar värdet i variablen total i en funktion
return total;

divideTotal(total, numberOfFriends);

//Hämtar det som skrivits i inputfältet med ID numberOfFriends
document.getElementById('numberOfFriends').value;